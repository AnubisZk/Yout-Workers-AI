import streamlit as st
import pandas as pd
import openai

# --- Config ---
st.set_page_config(page_title="Youth Report Bot", page_icon="📊")
st.title("🤖 Youth Report Bot")

# --- OpenAI API Key (to be replaced with your own) ---
openai.api_key = st.secrets.get("OPENAI_API_KEY", "sk-...YOUR-KEY...")

# --- Upload Section ---
uploaded_file = st.file_uploader("Upload a CSV or Excel file with participant feedback", type=["csv", "xlsx"])

if uploaded_file:
    if uploaded_file.name.endswith(".csv"):
        df = pd.read_csv(uploaded_file)
    else:
        df = pd.read_excel(uploaded_file)

    st.subheader("📄 Preview of Uploaded Data")
    st.dataframe(df.head())

    feedback_column = st.selectbox("Select the column containing participant feedback", df.columns)

    if st.button("🧠 Generate Report Summary"):
        with st.spinner("Analyzing feedback and generating summary..."):
            combined_text = "\n".join(df[feedback_column].dropna().astype(str).tolist())

            prompt = f"""
            You are a reporting assistant for youth workers. Analyze the following participant feedback and generate:
            - 3 key highlights
            - 2 areas of improvement
            - A short paragraph to be used in an official report.

            Feedback:
            {combined_text}
            """

            try:
                response = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": "You are an expert youth work reporting assistant."},
                        {"role": "user", "content": prompt}
                    ]
                )
                result = response['choices'][0]['message']['content']
                st.subheader("📋 AI-Generated Summary")
                st.markdown(result)
            except Exception as e:
                st.error(f"Error from OpenAI: {e}")

# --- Footer ---
st.markdown("""
---
Made with ❤️ for youth workers. [GitHub](https://github.com/YOUR_USERNAME/youth-report-bot)
""")